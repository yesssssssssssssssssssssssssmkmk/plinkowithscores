# Plinko-with-score
Here I have created the plinko game with score in it.{project (WhitehatJR) C33}
